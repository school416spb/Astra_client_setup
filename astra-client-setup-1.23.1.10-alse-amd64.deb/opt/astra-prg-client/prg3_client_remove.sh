#!/bin/bash
echo "УСТАНОВКА ДЕСКТОП КЛИЕНТА ПАРАГРАФ 3 В ASTRA LINUX SE 1.7"

VERSION=$(</etc/astra_version)
SUB="1.7"

if [[ ! "$VERSION" =~ .*"$SUB".* ]]; then
    echo "Необходима ОС Astra Linux SE 1.7! Завершение..."
    exit
else
    cd $HOME/.wine/drive_c/Program\ Files\ \(x86\)/Paragraf/uninst/
    wine unins000.exe
    cd ../..
    rm -r Paragraf/
    rm $HOME/Desktop/Параграф\ 3.desktop
    exit
fi
