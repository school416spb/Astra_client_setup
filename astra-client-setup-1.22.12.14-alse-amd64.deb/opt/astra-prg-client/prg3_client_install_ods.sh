#!/bin/bash
echo "УСТАНОВКА ДЕСКТОП КЛИЕНТА ПАРАГРАФ 3 В ASTRA LINUX SE 1.7"

VERSION=$(</etc/astra_version)
SUB="1.7"

if [[ ! "$VERSION" =~ .*"$SUB".* ]]; then
    echo "Необходима ОС Astra Linux SE 1.7! Завершение..."
    exit
fi
    
if [[ ! -f '/opt/wine-7.13/bin/wine' ]]; then
    sudo apt install ia32-libs
    wget https://easyastra.ru/files/soft/wine_7.13-0-astra-se17_amd64.deb
    sudo dpkg -i wine_7.13-0-astra-se17_amd64.deb
    rm wine_7.13-0-astra-se17_amd64.deb
    sudo ln -s /opt/wine-7.13/bin/wine /usr/bin/wine
    sudo apt install ca-certificates libmspack0 cabextract
    wget https://raw.githubusercontent.com/Winetricks/winetricks/master/src/winetricks
    chmod +x winetricks
    sudo mv winetricks /usr/bin/
    export WINE=/opt/wine-7.13/bin/wine
    /opt/wine-7.13/bin/winecfg
    wget https://easyastra.ru/files/soft/client_setup.exe
    wine client_setup.exe
    rm client_setup.exe
    wget https://easyastra.ru/files/soft/prg3_client_icon.png
    mv prg3_client_icon.png $HOME/.astra-prg-client/prg3_client_icon.png
    rm $HOME/Desktop/'Параграф 3.lnk'
    echo '[Desktop Entry]' > $HOME/Desktop/'Параграф 3.desktop'
    echo 'Name=Параграф 3' >> $HOME/Desktop/'Параграф 3.desktop'
    echo 'Exec=wine .wine/drive_c/Program\ Files\ \(x86\)/Paragraf/client.exe' >> $HOME/Desktop/'Параграф 3.desktop' 
    echo 'Type=Application' >> $HOME/Desktop/'Параграф 3.desktop'
    echo 'StartupNotify=true' >> $HOME/Desktop/'Параграф 3.desktop'
    echo 'Path=' >> $HOME/Desktop/'Параграф 3.desktop'
    echo 'Icon=$HOME/.astra-prg-client/prg3_client_icon.png' >> $HOME/Desktop/'Параграф 3.desktop'
    echo 'StartupWMClass=client.exe' >> $HOME/Desktop/'Параграф 3.desktop'
    wget https://easyastra.ru/files/soft/LibreOffice_x86.msi
    wine LibreOffice_x86.msi
    rm LibreOffice_x86.msi
else
    wget https://easyastra.ru/files/soft/client_setup.exe
    wine client_setup.exe
    rm client_setup.exe
    wget https://easyastra.ru/files/soft/prg3_client_icon.png
    mv prg3_client_icon.png $HOME/.astra-prg-client/prg3_client_icon.png
    rm $HOME/Desktop/'Параграф 3.lnk'
    echo '[Desktop Entry]' > $HOME/Desktop/'Параграф 3.desktop'
    echo 'Name=Параграф 3' >> $HOME/Desktop/'Параграф 3.desktop'
    echo 'Exec=wine .wine/drive_c/Program\ Files\ \(x86\)/Paragraf/client.exe' >> $HOME/Desktop/'Параграф 3.desktop' 
    echo 'Type=Application' >> $HOME/Desktop/'Параграф 3.desktop'
    echo 'StartupNotify=true' >> $HOME/Desktop/'Параграф 3.desktop'
    echo 'Path=' >> $HOME/Desktop/'Параграф 3.desktop'
    echo 'Icon=$HOME/.astra-prg-client/prg3_client_icon.png' >> $HOME/Desktop/'Параграф 3.desktop'
    echo 'StartupWMClass=client.exe' >> $HOME/Desktop/'Параграф 3.desktop'
    wget https://easyastra.ru/files/soft/LibreOffice_x86.msi
    wine LibreOffice_x86.msi
    rm LibreOffice_x86.msi
fi
